<?php

namespace app\controllers;

use app\models\SpringFriend;
use app\models\SpringRecord;
use app\models\SpringUser;
use Yii;
use yii\base\Exception;
use yii\rest\ActiveController;
use yii\filters\Cors;
use yii\helpers\ArrayHelper;

class SpringController extends ActiveController
{
    public $modelClass = 'app\models\SpringRecord';

    public function behaviors()
    {
        return ArrayHelper::merge([
            [
                'class' => Cors::className(),
                'cors' => [
                    'Origin' => ['*'],
                    'Access-Control-Request-Method' => ['GET', 'HEAD', 'OPTIONS'],
                ],
            ],
        ], parent::behaviors());
    }

    function actionUpRecord($openid, $mediaid)
    {

        try {
            $wechat = \Yii::$app->wechat;
            if ($wechat->getMedia($mediaid)) {
                $amr = "/opt/userdata/wxcms/games/cj/record/" . $mediaid . ".amr";
                $mp3 = "/opt/userdata/wxcms/games/cj/mp3/" . $mediaid . ".mp3";
                $command = "ffmpeg -i $amr $mp3";
                system($command, $error);
                $sr = new SpringRecord();
                $sr->openid = $openid;
                $sr->record = $mediaid;
                $sr->time = time();
                $sr->save();
                return array('code' => 0, 'msg' => '录音上传成功');
            } else {
                return array('code' => 1, 'msg' => '录音上传失败');
            }
        } catch (Exception $e) {
            return array('code' => 1, 'msg' => '录音上传失败');
        }
    }

    function actionUserRecord($openid)
    {
        $sr = SpringRecord::findOne(array("openid" => $openid));
        return array('code' => 0, 'msg' => '成功', 'data' => $sr);
    }

    function actionUser($openid, $username, $avatar, $type)
    {
        try {
            $spu = SpringUser::find()->where(array("openid" => $openid))->one();
            if ($spu) {
                if ($type == 0) {
                    $spu->self = 1;
                } else {
                    $spu->friend = 1;
                }
                $spu->update();
                return 0;
            }
            $su = new SpringUser();
            $su->openid = $openid;
            $su->username = $username;
            $su->avatar = $avatar;
            if ($type == 0) {
                $su->self = 1;
            } else {
                $su->friend = 1;
            }
            $su->save();
            return 0;
        } catch (Exception $e) {
            return 1;
        }
    }

    function actionFriend($openid, $friend)
    {
        try {
            $e = SpringFriend::find()->where(array('openid' => $openid, 'friend' => $friend))->exists();
            if (!$e) {
                $f = SpringFriend::find()->where(array('openid' => $openid))->count();
                if ($f > 2) {
                    return 1;
                }
                $f = new SpringFriend();
                $f->openid = $openid;
                $f->friend = $friend;
                $f->save();
            }
            return 0;
        } catch (Exception $e) {
            return 1;
        }
    }

    function actionPrice($openid, $pwd)
    {
        if ($pwd < 7120 || $pwd > 7154) {
            if ($pwd != 1220) {
                return array('code' => 1, 'msg' => '密码错误');
            }
        }
        $spu = SpringUser::find()->where(array("openid" => $openid))->one();
        if (!empty($spu)) {
            $spu->pricestate = 1;
            $spu->dian = $pwd;
            $spu->update();
            return array('code' => 0, 'msg' => '兑换成功');
        } else {
            return array('code' => 1, 'msg' => '没有该用户');
        }
    }

    function actionPriceState($openid)
    {
        $spu = SpringUser::find()->where(array("openid" => $openid))->one();
        if (!empty($spu)) {
            if ($spu->friend == 0) {
                return 2;
            }
            return $spu->pricestate;
        } else {
            return 2;
        }
    }
}
