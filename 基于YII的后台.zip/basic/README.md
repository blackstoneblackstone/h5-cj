# 基于Yii2框架做的听故事应用
======

# 使用的技术

- yii2
- jplayer
- angularjs
