<?php
/**
 * Created by PhpStorm.
 * User: lihb
 * Date: 1/4/17
 * Time: 9:57 PM
 */

namespace app\models;

use yii\db\ActiveRecord;

class SpringFriend extends ActiveRecord
{

}